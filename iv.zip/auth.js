if(window.localStorage.getItem("token") == null || window.localStorage.getItem("token") == "" || window.localStorage.getItem("token") == "undefined"){
    window.location = "./";
}